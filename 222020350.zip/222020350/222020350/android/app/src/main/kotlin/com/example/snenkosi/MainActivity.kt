package com.example.snenkosi

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
