import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: ProfilePage(),
    );
  }
}

class ProfilePage extends StatefulWidget {
  @override
  _ProfilePageState createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {

  String name = "Snethemba";
  String surname = "Nkosi";
  String phone = "0711730966";
  String email = "mpilo@gmail.com";
  String role = "Software Developer";
  String language = "JavaScript";
  String imagePath = "assets/flowers.webp";

  void updateProfile(Map<String, String> data) {
    setState(() {
      name = data["name"]!;
      surname = data["surname"]!;
      phone = data["phone"]!;
      email = data["email"]!;
      role = data["role"]!;
      language = data["language"]!;
      imagePath = data["image"]!;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Profile Page"),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          children: [

            CircleAvatar(
              radius: 60,
              backgroundImage: AssetImage(imagePath),
            ),

            SizedBox(height: 20),

            Text("$name $surname",
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),

            SizedBox(height: 10),
            Text("Phone: $phone"),
            Text("Email: $email"),
            Text("Role: $role"),
            Text("Programming Language: $language"),

            SizedBox(height: 30),

            ElevatedButton(
              onPressed: () async {
                final result = await Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => EditProfilePage(
                      name: name,
                      surname: surname,
                      phone: phone,
                      email: email,
                      role: role,
                      language: language,
                      imagePath: imagePath,
                    ),
                  ),
                );

                if (result != null) {
                  updateProfile(result);
                }
              },
              child: Text("Edit Profile"),
            )
          ],
        ),
      ),
    );
  }
}

class EditProfilePage extends StatefulWidget {

  final String name;
  final String surname;
  final String phone;
  final String email;
  final String role;
  final String language;
  final String imagePath;

  EditProfilePage({
    required this.name,
    required this.surname,
    required this.phone,
    required this.email,
    required this.role,
    required this.language,
    required this.imagePath,
  });

  @override
  _EditProfilePageState createState() => _EditProfilePageState();
}

class _EditProfilePageState extends State<EditProfilePage> {

  late TextEditingController nameController;
  late TextEditingController surnameController;
  late TextEditingController phoneController;
  late TextEditingController emailController;
  late TextEditingController roleController;
  late TextEditingController languageController;
  late String imagePath;

  @override
  void initState() {
    super.initState();
    nameController = TextEditingController(text: widget.name);
    surnameController = TextEditingController(text: widget.surname);
    phoneController = TextEditingController(text: widget.phone);
    emailController = TextEditingController(text: widget.email);
    roleController = TextEditingController(text: widget.role);
    languageController = TextEditingController(text: widget.language);
    imagePath = widget.imagePath;
  }

  void updateImage() {
    setState(() {
      imagePath = "assets/flower.webp";
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Edit Profile")),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(20),
        child: Column(
          children: [

            CircleAvatar(
              radius: 60,
              backgroundImage: AssetImage(imagePath),
            ),

            TextButton(
              onPressed: updateImage,
              child: Text("Change Image"),
            ),

            TextField(
              controller: nameController,
              decoration: InputDecoration(labelText: "Name"),
            ),
            TextField(
              controller: surnameController,
              decoration: InputDecoration(labelText: "Surname"),
            ),
            TextField(
              controller: phoneController,
              decoration: InputDecoration(labelText: "Phone"),
            ),
            TextField(
              controller: emailController,
              decoration: InputDecoration(labelText: "Email"),
            ),
            TextField(
              controller: roleController,
              decoration: InputDecoration(labelText: "Role"),
            ),
            TextField(
              controller: languageController,
              decoration: InputDecoration(labelText: "Programming Language"),
            ),

            SizedBox(height: 20),

            ElevatedButton(
              onPressed: () {
                Navigator.pop(context, {
                  "name": nameController.text,
                  "surname": surnameController.text,
                  "phone": phoneController.text,
                  "email": emailController.text,
                  "role": roleController.text,
                  "language": languageController.text,
                  "image": imagePath,
                });
              },
              child: Text("Update Profile"),
            )
          ],
        ),
      ),
    );
  }
}